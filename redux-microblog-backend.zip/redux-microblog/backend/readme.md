## Microblog Backend

1.  Clone this repository and `cd` into it
2.  `psql < schema.sql`
3.  `npm install`
4.  `nodemon`

All routes are prefixed with `/api` so to fetch posts the route is `GET /api/posts`
